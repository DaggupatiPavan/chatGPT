#!/bin/bash

count=$(sudo grep -ic "sendCloudEvent" /var/log/syslog)
#echo "$count"

ip_addr=$(curl -sL ifconfig.me)
rm -rf /home/ubuntu/cd_events/*

for i in $(seq "$count"); do
    line_numbers=$(sudo cat -n /var/log/syslog | grep -m$i "sendCloudEvent" | awk -v line="$i" '$0 ~ "sendCloudEvent" && NR == line {print $1}')

    while IFS= read -r line_number; do
       sudo tail -n+$line_number /var/log/syslog | head -29 >> /home/ubuntu/cd_events/final_log_$i
    done <<< "$line_numbers"

    if [[ $(grep -A 28 "sendCloudEvent: {" /home/ubuntu/cd_events/final_log_$i | head -1 | awk -F "t: " '{print $2}' | tr -d '[:space:]') == '{' && $(grep -A 28 "sendCloudEvent: {" /home/ubuntu/cd_events/final_log_$i | tail -1 | cut -d ":" -f 4 | tr -d '[:space:]') == '}' ]]; then
        #echo "final_log_$i"
        sed -i "1s/.*/a b c d e {/" /home/ubuntu/cd_events/final_log_$i
        cat /home/ubuntu/cd_events/final_log_$i | awk '{ print $6 $7 $8}' | jq '.' > /home/ubuntu/cd_events/output_$i.json
        var=$(cat /home/ubuntu/cd_events/output_"$i".json | jq -r ".pipelinename")
        mv /home/ubuntu/cd_events/output_$i.json /home/ubuntu/cd_events/"$var"
        echo "cloud event json file generated succesfully for the pipeline job : - /home/ubuntu/cd_events/$var"
        sed -i 's/"/\\"/g' /home/ubuntu/cd_events/"$var"
        rm -rf /home/ubuntu/cd_events/final_log_$i
        echo -e "curl -sL -X POST -H 'Content-Type: application/json' -u admin:admin -d '{\"properties\":{},\"routing_key\":\"demo\",\"payload\":\"\n$(cat /home/ubuntu/cd_events/"$var")" > /home/ubuntu/cd_events/"$var"
        echo -e "\",\"payload_encoding\":\"string\"}' http://$ip_addr:15672/api/exchanges/%2F/amq.default/publish" >> /home/ubuntu/cd_events/"$var"
    else
        rm -rf /home/ubuntu/cd_events/final_log_$i
    fi

    # echo "-----------------------------------------------------------------------------------------------------------" >> ~/final_log
done
