#!/bin/bash

count=$(sudo grep -ic "sendCloudEvent" /var/log/syslog)
#echo "$count"

ip_addr=$(curl -sL ifconfig.me)
rm -rf ~/cd_events/*

for i in $(seq "$count"); do
    line_numbers=$(sudo cat -n /var/log/syslog | grep -m$i "sendCloudEvent" | awk -v line="$i" '$0 ~ "sendCloudEvent" && NR == line {print $1}')

    while IFS= read -r line_number; do
        tail -n+$line_number /var/log/syslog | head -29 >> ~/cd_events/final_log_$i
    done <<< "$line_numbers"

    if [[ $(grep -A 28 "sendCloudEvent: {" ~/cd_events/final_log_$i | head -1 | awk -F "t: " '{print $2}' | tr -d '[:space:]') == '{' && $(grep -A 28 "sendCloudEvent: {" ~/cd_events/final_log_$i | tail -1 | cut -d ":" -f 4 | tr -d '[:space:]') == '}' ]]; then
        #echo "final_log_$i"
        sed -i "1s/.*/a b c d e {/" ~/cd_events/final_log_$i
        cat ~/cd_events/final_log_$i | awk '{ print $6 $7 $8}' | jq '.' > ~/cd_events/output_$i.json
        var=$(cat ~/cd_events/output_$i.json | jq -r ".pipelinename")
        mv ~/cd_events/output_$i.json ~/cd_events/"$var" 
        echo "cloud event json file generated succesfully for the pipeline job : - ~/cd_events/$var"
	sed -i 's/"/\\"/g' ~/cd_events/"$var"
        rm -rf ~/cd_events/final_log_$i 
	echo -e "curl -sL -X POST -H 'Content-Type: application/json' -u admin:admin -d '{\"properties\":{},\"routing_key\":\"demo\",\"payload\":\"\n$(cat ~/cd_events/"$var")" > ~/cd_events/"$var" 
	echo -e "\",\"payload_encoding\":\"string\"}' http://$ip_addr:15672/api/exchanges/%2F/amq.default/publish" >> ~/cd_events/"$var"
    else
        rm -rf ~/cd_events/final_log_$i
    fi

    # echo "-----------------------------------------------------------------------------------------------------------" >> ~/final_log
done
